import { Accounts } from 'meteor/accounts-base';

Accounts.ui.config({
	requestPermissions: {
    	facebook: ['user_likes'],
    	github: ['user', 'repo']
  	},
  	requestOfflineToken: {
   		 google: true
  	},
	passwordSignupFields : 'USERNAME_ONLY',
})