import { Meteor } from 'meteor/meteor';
import { Mongo } from 'meteor/mongo';
import { check } from 'meteor/check';

export var Items = new Mongo.Collection('items');

if (Meteor.isServer) {
	// This code only runs on the server
	Meteor.publish('items', function itemsPublication() {
		return Items.find({owner: this.userId});
		
	});

}

Meteor.methods({

	'items.insert': function(name, amount){
		check(name, String);
		check(amount, String);
	
	// is user loggin in before adding items
		if (! this.userId) {
			 throw new Meteor.Error('not-authorized');
		}

		Items.insert({
	        name: name,
	        amount: amount,
	        createdAt : new Date(),
	        owner: this.userId,
			username: Meteor.users.findOne(this.userId).username,
	        
	    });
	},

	'items.remove': function(itemId){
		check(itemId, String);

		// if (item.owner != this.userId) {
		// 	 throw new Meteor.Error('not-authorized');
		// }
		Items.remove(itemId);
	},

	'items.setChecked': function(itemId, setChecked){
		check(itemId, String);
		check(setChecked, Boolean);
		// if (item.owner != this.userId) {
		// 	 throw new Meteor.Error('not-authorized');
		// }
		Items.update(itemId, {
			$set: { checked: setChecked } });
	},

	'items.clear-list': function(){
		if (! this.userId) {
			 throw new Meteor.Error('not-authorized');
		}
		Items.remove({});
	}

});
