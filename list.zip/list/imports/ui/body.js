import { Template } from 'meteor/templating';
import { ReactiveDict } from 'meteor/reactive-dict';
import { Items } from '../api/items.js';

import './item.js';
import './body.html';

Template.body.onCreated(function bodyOnCreated() {
	this.state = new ReactiveDict();
	this.autorun(() => {
		this.subscribe('items', this.userId);
	});
});

Template.body.helpers({
    items: function(){
    	var instance = Template.instance();
    	if(instance.state.get('hide-checked')){
    		return Items.find({checked: { $ne: true} }, {sort: { createdAt: -1} } );
    	}
      	return Items.find({}, {sort: { createdAt: -1} } );
    }
});

  
Template.body.events({
	'submit .new-item': function(event) {
		event.preventDefault();
      	//get value from input element
      	var name = event.target.name.value;
      	var amount = event.target.amount.value;
      	//insert one item into the items collections
      	// Items.insert({
       //  	name : name,
       //  	amount: amount,
       //  	owner: Meteor.userId(),
       //  	username: Meteor.user().username,
       //  	createdAt : new Date()
       //  });
        Meteor.call('items.insert', name, amount);

      //clear form
      	event.target.name.value = '';
      	event.target.amount.value = ''; 
    },

    'change .hide-checked input': function(event, instance){
    	instance.state.set('hide-checked', event.target.checked);
    },

    // 'change .clear-list': function(event, instance){
    // 	instance.state.set('clear-list', event.target.clicked);
    // }

    'click .clear-list': function(){
    	// $('li').remove();
    	Meteor.call('items.clear-list');
    	
    }
});