import { Template } from 'meteor/templating';
import { Items } from '../api/items.js';

import './item.html';

// Template.item.helpers({
// 	isOwner: function(){
// 		return this.owner === Meteor.userId();
// 	}
    
// });

Template.item.events({

	'click .btn-danger': function() {
    	// Items.remove(this._id);
    	Meteor.call('items.remove', this._id);
    },

    'click .toggle-checked': function(){
    // Set the checked property to the opposite of its current value
    	// Items.update(this._id, {
    	// 	$set: { checked: !this.checked },
    	// });
    	Meteor.call('items.setChecked', this._id, !this.checked);
    }

    
});